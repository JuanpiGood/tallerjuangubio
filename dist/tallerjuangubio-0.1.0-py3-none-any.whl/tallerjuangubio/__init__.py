def hola():
    print("Hola, soy JuanGubio!")

__version__ = "0.1.0"