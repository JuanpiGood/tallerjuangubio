def hola():
    return "Hola, soy JuanGubio! 🚀"

def main():
    print(hola())

__version__ = "0.1.0"